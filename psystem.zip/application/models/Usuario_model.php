<?php

class Usuario_model extends CI_Model {

    function __construct() {

        parent::__construct();
    }

    public function cadastro() {
        //Recebe os dados
        $data['nome_usuario'] = $this->input->post('nome_usuario');
        $data['email_usuario'] = $this->input->post('email_usuario');
        $data['nivel_usuario'] = $this->input->post('nivel_usuario');
        $data['senha_usuario'] = sha1($this->input->post('senha_usuario'));
        $data['status_usuario'] = 1;

        //Tenta cadastrar 
        if ($this->db->insert('usuario', $data)) {
            //Se cadastrar retorna 1
            return 1;
        } else {
            //Senão cadastrar retorna 2
            return 2;
        }
    }

    public function lista() {
        //Seleciona ad colunas do banco de dados
        $this->db->select('id_usuario, nome_usuario, email_usuario, nivel_usuario, status_usuario');

        //realiza a consulta
        return $this->db->get('usuario')->result();
    }
    
    public function editar() {
        //Recebe os dados
        $id = $this->input->post('id');
        $data['nome_usuario'] = $this->input->post('nome_usuario');
        $data['email_usuario'] = $this->input->post('email_usuario');
        $data['nivel_usuario'] = $this->input->post('nivel_usuario');

        $this->db->where('id_usuario', $id);
        
        //Tenta editar 
        if ($this->db->update('usuario', $data)) {
            //Se editar retorna 1
            return 1;
        } else {
            //Senão editar retorna 2
            return 2;
        }
    }
    
    public function excluir() {
        //Recebe os dados
        $id = $this->input->post('id');

        $this->db->where('id_usuario', $id);
        
        //Tenta excluir
        if ($this->db->delete('usuario')) {
            //Se excluir retorna 1
            return 1;
        } else {
            //Senão excluir retorna 2
            return 2;
        }
    }

}
