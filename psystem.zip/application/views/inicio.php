<?php if ($this->session->flashdata('class')) { ?>

    <div class="alert alert-<?= $this->session->flashdata('class'); ?>" role="alert">

        <?= $this->session->flashdata('inicio'); ?>

    </div>


<?php } ?>

<?= $this->session->cd; ?>