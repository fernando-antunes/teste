<div class="col-md-12">

    <?php if ($this->session->flashdata('class')) { ?>

        <div class="alert alert-<?= $this->session->flashdata('class'); ?>" role="alert">

            <?= $this->session->flashdata('paciente'); ?>

        </div>


    <?php } ?>

    <div class="container">

        <div class="row">

            <!--Titulo da página-->
            <legend>
                <h2>Cadastro do Paciente</h2>
            </legend>

            <!--Texto de orientação-->
            <h5>Todos os campos com <font color="red">*</font> são obrigatório</h5>

        </div>

        <!--Formulário-->
        <form method="POST" action="<?= base_url('paciente/cadastro'); ?>">

            <div class="row">

                <!--Nome do Paciente-->
                <div class="col-md-4">

                    <label for="nome_paciente">Nome <font color="red">*</font></label>
                    <input type="text" name="nome_paciente" placeholder="Digite seu nome" class="form-control" required autofocus>

                </div>

                <!--E-mail do Paciente-->
                <div class="col-md-4">

                    <label for="email_paciente">E-mail <font color="red">*</font></label>
                    <input type="email" name="email_paciente" placeholder="Digite seu email" class="form-control" required>


                </div>

                <!--CPF do Paciente-->
                <div class="col-md-4">

                    <label for="cpf_paciente">CPF <font color="red">*</font></label>
                    <input type="text" name="cpf_paciente" placeholder="Digite seu CPF" class="form-control" required>


                </div>

            </div>

            <br>

            <div class="row">

                <!--Endereço do Paciente-->
                <div class="col-md-4">

                    <label for="end_paciente">Endereço <font color="red">*</font></label>
                    <input type="text" name="end_paciente" placeholder="Digite seu Endereço" class="form-control" required>


                </div>

                <!--Celular do Paciente-->
                <div class="col-md-3">

                    <label for="contato1_paciente">Celular <font color="red">*</font></label>
                    <input type="contato1" name="contato1_paciente" placeholder="Celular" class="form-control" required>


                </div>

                <!--Telefone Residencial do Paciente-->
                <div class="col-md-3">

                    <label for="contato2_paciente">Telefone Residencial <font color="red">*</font></label>
                    <input type="contato2" name="contato2_paciente" placeholder="Telefone Residencial" class="form-control" required>


                </div>

                <!--Senha do Paciente-->
                <div class="col-md-2">

                    <label for="senha_paciente">Senha <font color="red">*</font></label>
                    <input type="password" name="senha_paciente" placeholder="Digite sua senha" class="form-control" required>

                </div>

            </div>

            <br>

            <div class="row">

                <div class="col-md-12">

                    <!--Botão de cadastro-->
                    <button type="submit" class="btn btn-primary">Salvar</button>

                </div>

            </div>
        </form>

        <br>

        <table class="table table-hover table-striped">

            <tr>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Nível</th>
                <th>Ação</th>
            </tr>

            <?php foreach ($lista as $lis) { ?>

                <tr>
                    <td><?= $lis->nome_paciente; ?></td>
                    <td><?= $lis->email_paciente; ?></td>


                    <td>
                        <button class="btn btn-warning">Editar</button>
                        <button class="btn btn-danger">Excluir</button>
                    </td>
                </tr>

            <?php } ?>





        </table>

    </div>

</div>