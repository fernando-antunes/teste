<html>
    <head>
        <title>Psystem</title>
        <!--Chama o css da pagina-->
        <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.css'); ?>">
        
        <!--Chama o js da pagina-->
        <script src="<?= base_url('assets/js/jquery.js'); ?>"></script>
        <script src="<?= base_url('assets/js/bootstrap.js'); ?>"></script>
    </head>
    <body>
        <nav class="navbar navbar-default navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Psystem</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li><a href="<?= base_url('inicio'); ?>">Início</a></li>
                        <li><a href="<?= base_url('usuario'); ?>">Usuário</a></li>
                        <li><a href="<?= base_url('psicologo'); ?>">Psicólogo</a></li>
                        <li><a href="<?= base_url('paciente'); ?>">Paciente</a></li>
                        <li><a href="">Consulta</a></li>
                    </ul>
                    <ul class="nav navbar-nav navbar-right">

                        <li><a href="">Perfil</a></li>
                        <li><a href="">Sair</a></li>
                    </ul>
                </div><!--/.nav-collapse -->
            </div>
        </nav>
        <br>
        <br>
        <br>
    </body>
</html>