<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

    //GFunção responsaval por chamar a pagina de login
    public function index() {
        //Chamar pagina de login
        $this->load->view('login/login');
    }
    
    public function logar() {
        
        //Chamar a model
        $this->load->model('login_model', 'login');

        //Faz o cadastro
        switch ($this->login->logar()) {
            case 1:

                $this->session->set_flashdata('inicio', 'Bem vindo ao Psystem!');
                $this->session->set_flashdata('class', 'success');

                redirect('inicio');

                break;

            case 2:

                $this->session->set_flashdata('login', 'Senha ou e-mail errado!');
                $this->session->set_flashdata('class', 'danger');

                redirect('login');

                break;

            default:

                $this->session->set_flashdata('login', 'Senha ou e-mail errado!');
                $this->session->set_flashdata('class', 'danger');

                redirect('login');

                break;
        }
    }

}
