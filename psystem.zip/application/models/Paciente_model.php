<?php

class Paciente_model extends CI_Model {

    function __construct() {

        parent::__construct();
    }

    public function cadastro() {
        //Recebe os dados
        $data['nome_paciente'] = $this->input->post('nome_paciente');
        $data['email_paciente'] = $this->input->post('email_paciente');
        $data['cpf_paciente'] = $this->input->post('cpf_paciente');
        $data['senha_paciente'] = sha1($this->input->post('senha_paciente'));

        //Tenta cadastrar 
        if ($this->db->insert('paciente', $data)) {
            //Se cadastrar retorna 1
            return 1;
        } else {
            //Senão cadastrar retorna 2
            return 2;
        }
    }

    public function lista() {
        //Seleciona a colunas do banco de dados
        $this->db->select('id_paciente, nome_paciente, email_paciente, cpf_paciente, contato1_paciente, contato2_paciente');

        //realiza a consulta
        return $this->db->get('paciente')->result();
    }

}
