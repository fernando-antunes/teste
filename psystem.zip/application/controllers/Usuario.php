<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Usuario extends CI_Controller {

//Manter Usúario
    public function index() {
        //Chamar a model
        $this->load->model('usuario_model', 'usu');
        
        $data['lista'] = $this->usu->lista();
        
        $this->load->view('menu/menu');
        $this->load->view('usuario/usuario', $data);
    }

//Cadastrar Usúario
    public function cadastro() {

        //Chamar a model
        $this->load->model('usuario_model', 'usu');

        //Faz o cadastro
        switch ($this->usu->cadastro()) {
            case 1:

                $this->session->set_flashdata('usuario', 'Usuário cadastrado com sucesso!');
                $this->session->set_flashdata('class', 'success');

                redirect('usuario');

                break;

            case 2:

                $this->session->set_flashdata('usuario', 'Erro ao cadastrar usuário!');
                $this->session->set_flashdata('class', 'danger');

                redirect('usuario');

                break;

            default:

                $this->session->set_flashdata('usuario', 'Erro ao cadastrar usuário!');
                $this->session->set_flashdata('class', 'danger');

                redirect('usuario');

                break;
        }
    }
    
    //Editar Usúario
    public function editar() {

        //Chamar a model
        $this->load->model('usuario_model', 'usu');

        //Faz a edição
        switch ($this->usu->editar()) {
            case 1:

                $this->session->set_flashdata('usuario', 'Usuário editado com sucesso!');
                $this->session->set_flashdata('class', 'success');

                redirect('usuario');

                break;

            case 2:

                $this->session->set_flashdata('usuario', 'Erro ao editar o usuário!');
                $this->session->set_flashdata('class', 'danger');

                redirect('usuario');

                break;

            default:

                $this->session->set_flashdata('usuario', 'Erro ao editar o usuário!');
                $this->session->set_flashdata('class', 'danger');

                redirect('usuario');

                break;
        }
    }
    
    //Excluir Usúario
    public function excluir() {

        //Chamar a model
        $this->load->model('usuario_model', 'usu');

        //Faz a edição
        switch ($this->usu->excluir()) {
            case 1:

                $this->session->set_flashdata('usuario', 'Usuário excluído com sucesso!');
                $this->session->set_flashdata('class', 'success');

                redirect('usuario');

                break;

            case 2:

                $this->session->set_flashdata('usuario', 'Erro ao excluir o usuário!');
                $this->session->set_flashdata('class', 'danger');

                redirect('usuario');

                break;

            default:

                $this->session->set_flashdata('usuario', 'Erro ao excluir o usuário!');
                $this->session->set_flashdata('class', 'danger');

                redirect('usuario');

                break;
        }
    }

}
