<div class="col-md-12">

    <?php if ($this->session->flashdata('class')) { ?>

        <div class="alert alert-<?= $this->session->flashdata('class'); ?>" role="alert">

            <?= $this->session->flashdata('psicologo'); ?>

        </div>


    <?php } ?>

    <div class="container">

        <div class="row">

            <!--Titulo da página-->
            <legend>
                <h2>Cadastro do Psicólogo</h2>
            </legend>

            <!--Texto de orientação-->
            <h5>Todos os campos com <font color="red">*</font> são obrigatório</h5>

        </div>

        <!--Formulário-->
        <form method="POST" action="<?= base_url('psicologo/cadastro'); ?>">

            <div class="row">

                <!--Nome do Psicólogo-->
                <div class="col-md-4">

                    <label for="nome_psicologo">Nome <font color="red">*</font></label>
                    <input type="text" name="nome_psicologo" placeholder="Digite seu nome" class="form-control" required autofocus>

                </div>

                <!--E-mail do Psicólogo-->
                <div class="col-md-3">

                    <label for="email_psicologo">E-mail <font color="red">*</font></label>
                    <input type="email" name="email_psicologo" placeholder="Digite seu email" class="form-control" required>


                </div>

                <!--Número de Registro do Psicólogo-->
                <div class="col-md-2">

                    <label for="crp_psicologo">CRP <font color="red">*</font></label>
                    <input type="text" name="crp_psicologo" placeholder="Digite seu CRP" class="form-control" required>


                </div>

                <!--Celular do Psicólogo-->
                <div class="col-md-3">

                    <label for="contato1_psicologo">Celular <font color="red">*</font></label>
                    <input type="contato1" name="contato1_psicologo" placeholder="Celular" class="form-control" required>


                </div>

            </div>

            <br>

            <div class="row">

                <!--Telefone Residencial do Psicólogo-->
                <div class="col-md-3">

                    <label for="contato2_psicologo">Telefone Residencial <font color="red">*</font></label>
                    <input type="contato2" name="contato2_psicologo" placeholder="Telefone Residencial" class="form-control" required>


                </div>

                <!--Senha do Psicólogo-->
                <div class="col-md-3">

                    <label for="senha_psicologo">Senha <font color="red">*</font></label>
                    <input type="password" name="senha_psicologo" placeholder="Digite sua senha" class="form-control" required>

                </div>

            </div>

            <br>

            <div class="row">

                <div class="col-md-12">

                    <!--Botão de cadastro-->
                    <button type="submit" class="btn btn-primary">Salvar</button>

                </div>

            </div>
        </form>

        <br>

        <table class="table table-hover table-striped">

            <tr>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Nível</th>
                <th>Ação</th>
            </tr>

            <?php foreach ($lista as $lis) { ?>

                <tr>
                    <td><?= $lis->nome_psicologo; ?></td>
                    <td><?= $lis->email_psicologo; ?></td>

                    <td>
                        <?php
                        if ($lis->status_psicologo == 1) {
                            echo 'Ativo';
                        } else {
                            echo 'Cancelado';
                        }
                        ?>
                    </td>

                    <!--Botões de editar e excluir-->
                    <td>
                        <button class="btn btn-warning">Editar</button>
                        <button class="btn btn-danger">Excluir</button>
                    </td>
                </tr>

            <?php } ?>





        </table>

    </div>

</div>