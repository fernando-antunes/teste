<html>
    <head>
        <title>Psystem</title>

        <link rel="stylesheet" href="<?= base_url('assets/css/bootstrap.css'); ?>">
        <link rel="stylesheet" href="<?= base_url('assets/css/login.css'); ?>">
    </head>

    <body>
        <div class="container">

            <?php if ($this->session->flashdata('class')) { ?>

                <div class="alert alert-<?= $this->session->flashdata('class'); ?>" role="alert">

                    <?= $this->session->flashdata('login'); ?>

                </div>


            <?php } ?>

            <form class="form-signin" method="POST" action="<?= base_url('login/logar'); ?>">
                <!--Logo do sistema-->
                <h2 class="form-signin-heading"><img src="<?= base_url('assets/img/logo.png'); ?>" width="150px"></h2>
                <h2 class="form-signin-heading">Psystem</h2>

                <!--Campo de e-mail-->
                <label for="inputEmail" class="sr-only">Email address</label>
                <input type="email" name="email" class="form-control" placeholder="Digite seu e-mail" required autofocus>
                <!--Campo senha-->
                <label for="inputPassword" class="sr-only">Password</label>
                <input type="password" name="senha" class="form-control" placeholder="Digite sua senha" required>
                <!--Botão de entrada-->
                <button class="btn btn-lg btn-primary btn-block" type="submit">Entrar</button>
            </form>

        </div> <!-- /container -->
    </body>
</html>