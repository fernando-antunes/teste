<div class="col-md-12">

    <?php if ($this->session->flashdata('class')) { ?>

        <div class="alert alert-<?= $this->session->flashdata('class'); ?>" role="alert">

            <?= $this->session->flashdata('usuario'); ?>

        </div>


    <?php } ?>

    <div class="container">

        <div class="row">

            <!--Titulo da página-->
            <legend>
                <h2>Cadastro de Usuário</h2>
            </legend>

            <!--Texto de orientação-->
            <h5>Todos os campos com <font color="red">*</font> são obrigatório</h5>

        </div>

        <!--Formulário-->
        <form method="POST" action="<?= base_url('usuario/cadastro'); ?>">

            <div class="row">

                <!--Nome do usúario-->
                <div class="col-md-4">

                    <label for="nome_usuario">Nome <font color="red">*</font></label>
                    <input type="text" name="nome_usuario" placeholder="Digite seu nome" class="form-control" required autofocus>

                </div>

                <!--E-mail do usúario-->
                <div class="col-md-3">

                    <label for="email_usuario">E-mail <font color="red">*</font></label>
                    <input type="email" name="email_usuario" placeholder="Digite seu email" class="form-control" required>


                </div>

                <!--Nível do Usúario-->
                <div class="col-md-2">


                    <label for="nivel_usuario">Nível <font color="red">*</font></label>

                    <select name="nivel_usuario" class="form-control" required>

                        <option value="">Selecione</option>
                        <option value="1">Atendente</option>
                        <option value="2">Administrador</option>

                    </select>

                </div>

                <!--Senha do Usúario-->
                <div class="col-md-3">

                    <label for="nome_usuario">Senha <font color="red">*</font></label>
                    <input type="password" name="senha_usuario" placeholder="Digite sua senha" class="form-control" required>

                </div>

            </div>

            <br>

            <div class="row">

                <div class="col-md-12">

                    <!--Botão de cadastro-->
                    <button type="submit" class="btn btn-primary">Salvar</button>

                </div>

            </div>
        </form>

        <br>

        <table class="table table-hover table-striped">

            <tr>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Nível</th>
                <th>Status</th>
                <th>Ação</th>
            </tr>

            <?php foreach ($lista as $lis) { ?>

                <tr>
                    <td><?= $lis->nome_usuario; ?></td>
                    <td><?= $lis->email_usuario; ?></td>
                    <td>
                        <?php
                        if ($lis->nivel_usuario == 1) {
                            echo 'Atendente';
                        } else {
                            echo 'Administrador';
                        }
                        ?>
                    </td>
                    <td>
                        <?php
                        if ($lis->status_usuario == 1) {
                            echo 'Ativo';
                        } else {
                            echo 'Cancelado';
                        }
                        ?>
                    </td>
                    <td>
                        <button class="btn btn-warning" data-toggle="modal" data-target=".edi<?= $lis->id_usuario; ?>">Editar</button>
                        <button class="btn btn-danger" data-toggle="modal" data-target=".exc<?= $lis->id_usuario; ?>">Excluir</button>
                    </td>
                </tr>

                <div class="modal fade edi<?= $lis->id_usuario; ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
                    <div class="modal-dialog modal-lg" role="document">
                        <form method="POST" action="<?= base_url('usuario/editar'); ?>">
                            <input type="hidden" name="id" value="<?= $lis->id_usuario; ?>">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Editar usuário</h4>
                                </div>
                                <div class="modal-body">
                                    <div class="row">

                                        <!--Nome do usúario-->
                                        <div class="col-md-4">

                                            <label for="nome_usuario">Nome <font color="red">*</font></label>
                                            <input type="text" value="<?= $lis->nome_usuario; ?>" name="nome_usuario" placeholder="Digite seu nome" class="form-control" required autofocus>

                                        </div>

                                        <!--E-mail do usúario-->
                                        <div class="col-md-4">

                                            <label for="email_usuario">E-mail <font color="red">*</font></label>
                                            <input type="email" value="<?= $lis->email_usuario; ?>" name="email_usuario" placeholder="Digite seu email" class="form-control" required>


                                        </div>

                                        <!--Nível do Usúario-->
                                        <div class="col-md-4">


                                            <label for="nivel_usuario">Nível <font color="red">*</font></label>

                                            <select name="nivel_usuario" class="form-control" required>

                                                <option value="">Selecione</option>
                                                <option value="1" <?php
                                                if ($lis->nivel_usuario == 1) {
                                                    echo 'selected';
                                                }
                                                ?> >Atendente</option>
                                                <option value="2" <?php
                                                if ($lis->nivel_usuario == 2) {
                                                    echo 'selected';
                                                }
                                                ?>>Administrador</option>

                                            </select>

                                        </div>

                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Cancelar</button>
                                    <button type="submit" class="btn btn-success">Salvar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="modal fade exc<?= $lis->id_usuario; ?>" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
                    <div class="modal-dialog modal-lg" role="document">
                        <form method="POST" action="<?= base_url('usuario/excluir'); ?>">
                            <input type="hidden" name="id" value="<?= $lis->id_usuario; ?>">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title" id="myModalLabel">Excluir usuário</h4>
                                </div>
                                <div class="modal-body">
                                    <center>
                                        Você deseja realmente excluir o usuário <b><?= $lis->nome_usuario; ?></b>?
                                    </center>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Não</button>
                                    <button type="submit" class="btn btn-success">Sim</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

            <?php } ?>

        </table>

    </div>

</div>