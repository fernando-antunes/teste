<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Paciente extends CI_Controller {

//Manter Paciente
    public function index() {
        //Chamar a model
        $this->load->model('paciente_model', 'pac');
        
        $data['lista'] = $this->pac->lista();
        
        $this->load->view('menu/menu');
        $this->load->view('paciente/paciente', $data);
    }

//Cadastrar Paciente
    public function cadastro() {

        //Chamar a model
        $this->load->model('paciente_model', 'pac');

        //Faz o cadastro
        switch ($this->pac->cadastro()) {
            case 1:

                $this->session->set_flashdata('paciente', 'Paciente cadastrado com sucesso!');
                $this->session->set_flashdata('class', 'success');

                redirect('paciente');

                break;

            case 2:

                $this->session->set_flashdata('paciente', 'Erro ao cadastrar paciente!');
                $this->session->set_flashdata('class', 'danger');

                redirect('paciente');

                break;

            default:

                $this->session->set_flashdata('paciente', 'Erro ao cadastrar paciente!');
                $this->session->set_flashdata('class', 'danger');

                redirect('paciente');

                break;
        }
    }

}
