<?php

class Login_model extends CI_Model {

    function __construct() {

        parent::__construct();
    }

    public function logar() {
        //recebe os dados do login
        $email = $this->input->post('email');
        $senha = sha1($this->input->post('senha'));

        //filtra a consulta
        $this->db->where('email_usuario', $email);
        $this->db->where('senha_usuario', $senha);
        $this->db->where('status_usuario', 1);

        //realiza a consulta
        $data = $this->db->get('usuario')->result();

        //verifica se so foi encontrado um usuário
        if (count($data) == 1) {

            //pega os dados do usuário no banco
            $login['cd'] = $data[0]->id_usuario;
            $login['nivel'] = $data[0]->nivel_usuario;
            $login['logger'] = TRUE;

            //cria a sessão
            $this->session->set_userdata($login);

            //vai para a pagina principal
            return 1;
        } else {

            //volta para o login
            return 2;
        }
    }

}
