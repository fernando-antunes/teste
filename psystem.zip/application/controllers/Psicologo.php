<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Psicologo extends CI_Controller {

//Manter Psicólogo
    public function index() {
        //Chamar a model
        $this->load->model('psicologo_model', 'psi');

        $data['lista'] = $this->psi->lista();

        $this->load->view('menu/menu');
        $this->load->view('psicologo/psicologo', $data);
    }

//Cadastrar Psicólogo
    public function cadastro() {

        //Chamar a model
        $this->load->model('psicologo_model', 'psi');

        //Faz o cadastro
        switch ($this->psi->cadastro()) {
            case 1:

                $this->session->set_flashdata('psicologo', 'Psicólogo cadastrado com sucesso!');
                $this->session->set_flashdata('class', 'success');

                redirect('psicologo');

                break;

            case 2:

                $this->session->set_flashdata('psicologo', 'Erro ao cadastrar psicólogo!');
                $this->session->set_flashdata('class', 'danger');

                redirect('psicologo');

                break;

            default:

                $this->session->set_flashdata('psicologo', 'Erro ao cadastrar psicólogo!');
                $this->session->set_flashdata('class', 'danger');

                redirect('psicologo');

                break;
        }
    }

}
