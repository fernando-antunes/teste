<?php

class Psicologo_model extends CI_Model {

    function __construct() {

        parent::__construct();
    }

    public function cadastro() {
        //Recebe os dados
        $data['nome_psicologo'] = $this->input->post('nome_psicologo');
        $data['email_psicologo'] = $this->input->post('email_psicologo');
        $data['crp_psicologo'] = $this->input->post('crp_psicologo');
        $data['senha_psicologo'] = sha1($this->input->post('senha_psicologo'));
        $data['status_psicologo'] = 1;

        //Tenta cadastrar 
        if ($this->db->insert('psicologo', $data)) {
            //Se cadastrar retorna 1
            return 1;
        } else {
            //Senão cadastrar retorna 2
            return 2;
        }
    }

    public function lista() {
        //Seleciona ad colunas do banco de dados
        $this->db->select('id_psicologo, nome_psicologo, email_psicologo, crp_psicologo, status_psicologo, contato1_psicologo, contato2_psicologo');

        //realiza a consulta
        return $this->db->get('psicologo')->result();
    }

}
